const fs = require("fs");
const data = require('./metadata.json');
const bemuses = [];

var dir = './sounds';

if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir);
}

for (var filename in data.refs) {
    bemuses.push(fs.readFileSync(data.refs[filename].path));
}
var content = null;
for (var soundfilenames in data.files) {
    content = bemuses[data.files[soundfilenames].ref[0]].slice(data.files[soundfilenames].ref[1] + 14, data.files[soundfilenames].ref[2] + 14);
    fs.writeFile("sounds/" + data.files[soundfilenames].name, content, function(err) {
        if (err) {
            console.log('なんかおかしいめうンゴねぇ！');
            throw err;
        };
    });
}
console.log("done");