// ==UserScript==
// @name         GNQG replacer
// @namespace    https://twitter.com/cure_to_coma
// @version      0.4
// @description  hexさんとsayakaさんに許可をいただけました
// @match        https://*/*
// @match        http://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const regex1 = /(https?:\/\/)gnqg\.rosx\.net\/upload\/upload\.cgi\?get=(\d+)/g;
    const replacement1 = 'https://bms.hexlataia.xyz/mirror/gnqg-upload/$2.zip';

    const regex2 = /(https?:\/\/)absolute\.pv\.land\.to\/([^\/]+)\/src\/([\w.]+)/g;
    const replacement2 = 'https://mirror.lovelyrad.io/$2/src/$3';

    const regex3 = /(https?:\/\/)www\.dropbox\.com\/(.+)dl=0/g;
    const replacement3 = 'https://www.dropbox.com/$2dl=1';

    const regex4 = /(https?:\/\/)drive\.google\.com\/file\/d\/(.+?)\/view\?usp=sharing/g;
    const replacement4 = 'https://drive.google.com/u/0/uc?id=$2&export=download';

    let observerRuns = 0;


    function replaceLinks() {
        const nodes = document.querySelectorAll('body *');
        for (const node of nodes) {
            if (node.nodeType === Node.TEXT_NODE) {
                let matches = node.textContent.match(regex1);
                if (matches) {
                    node.textContent = node.textContent.replace(regex1, replacement1);
                }
                matches = node.textContent.match(regex2);
                if (matches) {
                    node.textContent = node.textContent.replace(regex2, replacement2);
                }
                matches = node.textContent.match(regex3);
                if (matches) {
                    node.textContent = node.textContent.replace(regex3, replacement3);
                }
                matches = node.textContent.match(regex4);
                if (matches) {
                    node.textContent = node.textContent.replace(regex4, replacement4);
                }
            } else if (node.nodeType === Node.ELEMENT_NODE) {
                const attributes = node.attributes;
                for (const attribute of attributes) {
                    const value = attribute.value;
                    if (typeof value === 'string') {
                        let newLink = value.replace(regex1, replacement1);
                        newLink = newLink.replace(regex2, replacement2);
                        newLink = newLink.replace(regex3, replacement3);
                        newLink = newLink.replace(regex4, replacement4);
                        if (newLink !== value) {
                            node.setAttribute(attribute.name, newLink);
                            if (node.nodeName === 'A') {
                                if (node.textContent === value) {
                                    node.textContent = newLink;
                                }
                                node.style.fontStyle = 'italic';
                                node.style.fontWeight = 'bold';
                            }
                        }
                    }
                }
            }
        }
        observerRuns++;
        if (observerRuns >= 3) {
            observer.disconnect();
        }
    }

    replaceLinks();

    const observer = new MutationObserver(replaceLinks);
    observer.observe(document.body, { childList: true, subtree: true });
})();
